#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
edge_concentration_newbery.py

Detect complete bipartite sub‑graphs (bicliques) between every pair of
adjacent layers of a directed layered graph and replace each biclique
by a dummy (concentrator) vertex, using Newbery’s heuristic
(Algorithm 13.14, Graph‑Drawing Handbook).

新增功能
---------
* 默认不执行 “子集合并” 步骤（‑s 关闭），这样 maximal biclique 如 {2,3}×{7,8}
  不会被拆分。
* 参数 -m 的默认值改为 0（原来是 1），防止因为 edge‑size 过滤掉
  单目标 biclique。
* 只实际浓缩两侧均至少包含 2 个顶点的 biclique（|S|≥2 且 |T|≥2），
  这正是 K₂,₂ 这类我们关心的情况。
* -d/--debug 可打印每层检测到的 biclique，便于验证。

使用示例
--------
    python edge_concentration_newbery.py -i INPUT_DIR -o OUTPUT_DIR
    # 若想使用原稿中的子集合并步骤则加上 -s
    # 若想把阈值改回 1（只保留 edge‑size ≥1 的 biclique）则使用 -m 1
"""

import argparse
from pathlib import Path
from typing import List, Tuple, Dict, Set, FrozenSet
from itertools import product


# ----------------------------------------------------------------------
# Ⅰ  I/O helpers
# ----------------------------------------------------------------------
def read_graph(p: Path) -> Tuple[int, int,
                                List[Tuple[int, int]],
                                List[List[int]]]:
    """Read a *.txt* file → (n,m,edges,layers)."""
    with p.open("r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]

    n, m = map(int, lines[0].split())
    edges = [tuple(map(int, lines[i].split())) for i in range(1, 1 + m)]

    k = int(lines[1 + m])                     # number of layers
    layers = [list(map(int, lines[2 + m + i].split()))
              for i in range(k)]

    return n, m, edges, layers


def write_graph(p: Path,
                n: int,
                m: int,
                edges: List[Tuple[int, int]],
                layers: List[List[int]]) -> None:
    """Write a graph using exactly the same format as the input."""
    with p.open("w", encoding="utf-8") as f:
        f.write(f"{n} {m}\n")
        for u, v in edges:
            f.write(f"{u} {v}\n")
        f.write(f"{len(layers)}\n")
        for layer in layers:
            f.write(" ".join(map(str, layer)) + "\n")


# ----------------------------------------------------------------------
# Ⅱ  Newbery’s biclique‑cover heuristic
# ----------------------------------------------------------------------
def newbery_biclique_cover(upper: List[int],
                           lower: List[int],
                           adj: Dict[int, Set[int]],
                           M: int,
                           subset_merge: bool = False,
                           debug: bool = False) -> List[Tuple[Set[int], Set[int]]]:
    """
    Return a biclique cover for the bipartite graph (upper, lower, adj)
    according to Newbery’s polynomial heuristic.

    Parameters
    ----------
    upper, lower : vertices of the two layers
    adj          : adjacency dict u → set(v)
    M            : lower bound for the edge‑size |S|·(|T|-1)
    subset_merge : if True, perform the original “subset‑merge” steps
                   (the handbook’s B2‑2).  When False those steps are
                   disabled – this keeps a maximal biclique such as
                   {2,3}×{7,8} intact.
    debug        : print intermediate bicliques
    """
    # ---------- B1 : all bicliques that have exactly two sources ----------
    B1: List[Tuple[FrozenSet[int], FrozenSet[int]]] = []
    for i in range(len(upper)):
        for j in range(i + 1, len(upper)):
            u, v = upper[i], upper[j]
            common = adj[u].intersection(adj[v])
            if common:                              # non‑empty intersection → a biclique
                B1.append((frozenset((u, v)), frozenset(common)))

    # sort by increasing |T| – the handbook does the same
    B1.sort(key=lambda x: len(x[1]))

    # ---------- B2 : current biclique cover (starts with the empty biclique) ----------
    B2: List[Tuple[Set[int], Set[int]]] = [(set(), set())]   # (S,T)

    for S_fz, T_fz in B1:
        S = set(S_fz)
        T = set(T_fz)

        # discard bicliques that are too small (edge‑size < M)
        if len(S) * (len(T) - 1) < M:
            continue

        # ----- first pass : does a biclique with the *same* target already exist? -----
        merged = False
        for idx, (Sy, Ty) in enumerate(B2):
            if T == Ty:
                B2[idx] = (Sy.union(S), Ty)
                merged = True
                break
        if merged:
            continue

        # ----- optional second pass : subset‑merge (the original B2‑2) -----
        if subset_merge:
            for idx, (Sy, Ty) in enumerate(B2):
                # case 1 : T ⊆ Ty
                if T.issubset(Ty):
                    B2.insert(0, (Sy.union(S), set(T)))   # new biclique at front
                    B2[idx] = (Sy, Ty.difference(T))      # shrink old target set
                    merged = True
                    break
                # case 2 : Ty ⊆ T
                if Ty.issubset(T):
                    B2.insert(0, (set(S), T.difference(Ty)))  # new biclique at front
                    B2[idx] = (Sy.union(S), Ty)                # enlarge source set of y
                    merged = True
                    break
            if merged:
                continue

        # ----- no merge possible → create a brand‑new biclique -----
        B2.insert(0, (set(S), set(T)))

    # ----------- post‑processing : keep only non‑empty targets & filter by M ----------
    target_to_source: Dict[FrozenSet[int], Set[int]] = {}
    for S, T in B2:
        if not T:
            continue                                    # ignore empty target
        if len(S) * (len(T) - 1) < M:
            continue                                    # discard tiny biclique
        key = frozenset(T)
        target_to_source.setdefault(key, set()).update(S)

    if debug:
        print("  Detected bicliques on this layer pair:")
        for tgt, src in target_to_source.items():
            print(f"    sources = {sorted(src)}   targets = {sorted(tgt)}")

    # return list of (source‑set , target‑set)
    return [(src, set(tgt)) for tgt, src in target_to_source.items()]


# ----------------------------------------------------------------------
# Ⅲ  Edge concentration for the whole layered graph
# ----------------------------------------------------------------------
def concentrate_edges(edges: List[Tuple[int, int]],
                     layers: List[List[int]],
                     M: int,
                     subset_merge: bool = False,
                     debug: bool = False) -> Tuple[List[Tuple[int, int]],
                                                List[List[int]]]:
    """
    Apply Newbery’s edge‑concentration to every adjacent‑layer pair.
    Returns (new_edges, new_layers) where dummy vertices have been inserted.
    """
    edge_set: Set[Tuple[int, int]] = set(edges)

    # first free vertex id (max existing id + 1)
    next_dummy = max(v for layer in layers for v in layer) + 1

    result_layers: List[List[int]] = []

    # --------------------------------------------------------------
    # Process each *original* adjacent pair (layer i, layer i+1)
    # --------------------------------------------------------------
    for i in range(len(layers) - 1):
        upper = layers[i]          # current upper layer
        lower = layers[i + 1]      # current lower layer

        # emit the upper layer (each original layer appears exactly once)
        result_layers.append(list(upper))

        # ----- build bipartite adjacency for this pair -----
        adj: Dict[int, Set[int]] = {u: set() for u in upper}
        for u, v in edge_set:
            if u in adj and v in lower:
                adj[u].add(v)

        # ----- run Newbery’s biclique cover -----
        bicliques = newbery_biclique_cover(upper, lower, adj,
                                           M, subset_merge, debug)

        # Keep only bicliques that really reduce the number of edges
        # (both sides contain at least two vertices → a genuine K_{≥2,≥2})
        bicliques = [(S, T) for S, T in bicliques
                     if len(S) >= 2 and len(T) >= 2]

        # ----- if we found any bicliques, insert a dummy layer -----
        if bicliques:
            dummy_layer: List[int] = []
            for S, T in bicliques:
                dummy = next_dummy
                next_dummy += 1
                dummy_layer.append(dummy)

                # delete original edges of the biclique
                for s, t in product(S, T):
                    edge_set.discard((s, t))

                # add the two‑hop edges via the dummy vertex
                for s in S:
                    edge_set.add((s, dummy))
                for t in T:
                    edge_set.add((dummy, t))

            # the dummy layer is placed **between** the two original layers
            result_layers.append(dummy_layer)

        # (no explicit “lower” layer here – it will become the upper layer
        #  of the next iteration)

    # after the loop, emit the very last original layer (the bottom one)
    result_layers.append(list(layers[-1]))

    # delete completely empty layers (can only happen when B1 was empty)
    compact_layers = [sorted(l) for l in result_layers if l]

    # deterministic ordering of the edge list
    new_edges = sorted(edge_set, key=lambda e: (e[0], e[1]))

    return new_edges, compact_layers


# ----------------------------------------------------------------------
# Ⅳ  File‑wise driver
# ----------------------------------------------------------------------
def process_one_file(in_path: Path,
                     out_path: Path,
                     M: int,
                     subset_merge: bool,
                     debug: bool) -> None:
    _, _, edges, layers = read_graph(in_path)

    new_edges, new_layers = concentrate_edges(edges, layers,
                                             M, subset_merge, debug)

    # recompute n (distinct vertices) and m
    all_vertices = {v for layer in new_layers for v in layer}
    new_n = len(all_vertices)
    new_m = len(new_edges)

    write_graph(out_path, new_n, new_m, new_edges, new_layers)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Edge concentration (Newbery’s heuristic) for layered "
                    "graphs. All *.txt* files in <input> are processed and "
                    "the optimised files are written to <output>."
    )
    parser.add_argument("-i", "--input", required=True,
                        help="Folder containing the source *.txt files.")
    parser.add_argument("-o", "--output", required=True,
                        help="Folder where the optimised *.txt files will be written.")
    parser.add_argument("-m", "--minsize", type=int, default=0,
                        help="Parameter M – lower bound on edge‑size |S|·(|T|-1). "
                             "A K₂,₂ has edge‑size 2, so any M ≤ 2 works. (default = 0).")
    parser.add_argument("-s", "--subset-merge", action="store_true",
                        help="Enable the original subset‑merge step (B2‑2).  By default it "
                             "is disabled so that maximal bicliques such as {2,3}×{7,8} are "
                             "kept intact.")
    parser.add_argument("-d", "--debug", action="store_true",
                        help="Print the bicliques that are discovered (debug mode).")
    args = parser.parse_args()

    in_dir = Path(args.input)
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    txt_files = list(in_dir.glob("*.txt"))
    if not txt_files:
        print(f"[!] No .txt files found in {in_dir}")
        return

    for src in txt_files:
        dst = out_dir / src.name
        print(f"Processing {src.name} …")
        process_one_file(src, dst,
                         M=args.minsize,
                         subset_merge=args.subset_merge,
                         debug=args.debug)

    print("All files processed.")


if __name__ == "__main__":
    main()
