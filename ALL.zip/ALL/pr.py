#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
最小 Feedback Arc Set（Exact via OR‑Tools） + PageRank‑FAS fallback
-----------------------------------------------------------------
读取 *.txt/*.gout → 求最小 FAS（ILP） → 若超时或求解失败则回退到
PageRank‑FAS（快速启发式） → 输出仍然是无环的 *.gout*（或 *.txt）文件。

使用方式
---------
    python min_fas_ilp.py -i ./input_folder -o ./output_folder -t 30 -v
"""

import argparse
import os
import sys
import time
from collections import deque
from typing import List, Tuple, Set

# --------------------------------------------------------------
# 1️⃣ 读取图（*.txt 或 *.gout）——格式完全相同
# --------------------------------------------------------------
def read_graph(path: str) -> Tuple[int, List[int], List[int]]:
    """读取 “n m\\n u v …” 的有向图文件，返回 (n, src, dst)。"""
    with open(path, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]

    if not lines:
        raise ValueError(f"Empty file: {path}")

    n_str, m_str = lines[0].split()
    n, m = int(n_str), int(m_str)

    src, dst = [], []
    for i, line in enumerate(lines[1:], start=1):
        u_str, v_str = line.split()
        u, v = int(u_str), int(v_str)
        if not (0 <= u < n and 0 <= v < n):
            raise ValueError(f"Vertex index out of range at line {i+1} in {path}")
        src.append(u)
        dst.append(v)

    if len(src) != m:
        raise ValueError(f"Declared m={m} but read {len(src)} edges in {path}")

    return n, src, dst


# --------------------------------------------------------------
# 2️⃣ PageRank‑FAS（快速启发式）——用于 warm‑start
# --------------------------------------------------------------
def pagerank_fas(
    n: int,
    src: List[int],
    dst: List[int],
    pr_iters: int = 20,
) -> Set[int]:
    """
    返回 **需要删除** 的边的 id（基于 PageRank 的启发式）。
    只做一个“粗糙的排序”，不保证最优，只是提供 warm‑start。
    """
    from ortools.linear_solver import pywraplp  # 只在这里导入，防止不必要的依赖

    m = len(src)

    # ---------- 1) 构造有向线图 L(G) ----------
    out_edges_of = [[] for _ in range(n)]
    in_edges_of = [[] for _ in range(n)]
    for e, (u, v) in enumerate(zip(src, dst)):
        out_edges_of[u].append(e)
        in_edges_of[v].append(e)

    L_adj = [[] for _ in range(m)]         # L(G) 的邻接表
    for v in range(n):
        for e_in in in_edges_of[v]:
            for e_out in out_edges_of[v]:
                L_adj[e_in].append(e_out)

    # ---------- 2) PageRank on L(G) ----------
    pr = [1.0 / m] * m
    for _ in range(pr_iters):
        nxt = [0.0] * m
        for i, neigh in enumerate(L_adj):
            if neigh:
                share = pr[i] / len(neigh)
                for j in neigh:
                    nxt[j] += share
            else:
                nxt[i] += pr[i]          # sink 保持分数
        pr = nxt

    # ---------- 3) 取前 30%（或全部）作为“要删”的候选 ----------
    sorted_edges = sorted(range(m), key=lambda e: -pr[e])
    cut = max(1, int(0.30 * m))               # 经验值 30%
    return set(sorted_edges[:cut])


# --------------------------------------------------------------
# 3️⃣ 最小 FAS 的 MIP（带 warm‑start）
# --------------------------------------------------------------
def solve_min_fas_ilp(
    n: int,
    src: List[int],
    dst: List[int],
    timelimit: int = 0,
    warm_start: Set[int] | None = None,
    verbose: bool = False,
) -> Tuple[Set[int], bool]:
    """
    返回要 **删除** 的边集合 (removed_set)。
    若在 timelimit（秒）内得到 optimal/feasible，则第二个返回值为 True；
    否则为 False（此时返回的集合可能是 warm‑start，或空集合）。
    """
    from ortools.linear_solver import pywraplp

    m = len(src)

    solver = pywraplp.Solver.CreateSolver("CBC_MIXED_INTEGER_PROGRAMMING")
    if solver is None:
        raise RuntimeError("Cannot create CBC solver – check OR‑Tools installation")

    # ---------- 变量 ----------
    # 顶点的排名（0 … n‑1）
    pos = [solver.IntVar(0, n - 1, f"pos_{v}") for v in range(n)]

    # keep[e] = 1 → 保留（前向），0 → 删除（加入 FAS）
    keep = [solver.BoolVar(f"keep_{e}") for e in range(m)]

    # ---------- 约束：消除环 ----------
    # pos[u] + 1 ≤ pos[v] + (1 - keep[e]) * n
    # 当 keep[e] = 1 时强制 u 在 v 前；keep[e] = 0 时约束自动满足
    for e, (u, v) in enumerate(zip(src, dst)):
        solver.Add(pos[u] + 1 <= pos[v] + (1 - keep[e]) * n)

    # ---------- 目标：最大化保留的边数（⇔最小化删除的边数） ----------
    obj = solver.Objective()
    for e in range(m):
        obj.SetCoefficient(keep[e], 1)
    obj.SetMaximization()

    # ---------- 求解时间上限 ----------
    if timelimit > 0:
        solver.SetTimeLimit(timelimit * 1000)   # 毫秒

    # ---------- Warm‑start（如果提供） ----------
    if warm_start is not None:
        # OR‑Tools 只在 solver 层提供 SetHint（而不是变量本身）
        # 我们把所有 keep[e] 的期望值一次性写进去
        hint_vars = []
        hint_vals = []
        for e in range(m):
            hint_vars.append(keep[e])
            hint_vals.append(0 if e in warm_start else 1)   # 0 → 删除，1 → 保留
        solver.SetHint(hint_vars, hint_vals)

    if verbose:
        print(f"  ILP model: n={n}, m={m}, timelimit={timelimit}s")
        if warm_start is not None:
            print(f"  Warm‑start includes {len(warm_start)} edges to delete")

    status = solver.Solve()

    # ---------- 状态解释 ----------
    ok = status in (solver.OPTIMAL, solver.FEASIBLE)
    if verbose:
        status_str = {
            solver.OPTIMAL:    "OPTIMAL",
            solver.FEASIBLE:   "FEASIBLE",
            solver.INFEASIBLE:"INFEASIBLE",
            solver.UNBOUNDED:  "UNBOUNDED",
            solver.ABNORMAL:  "ABNORMAL",
            solver.NOT_SOLVED:"NOT_SOLVED"
        }.get(status, "UNKNOWN")
        print(f"  Solver status: {status} ({status_str})")

    if not ok:
        # 若求解失败或超时，直接返回 warm‑start（若有）或空集合
        if warm_start is not None:
            return warm_start, False
        else:
            return set(), False

    # ---------- 读取解 ----------
    removed = {e for e in range(m) if int(keep[e].solution_value()) == 0}
    return removed, True


# --------------------------------------------------------------
# 4️⃣ 把去环后的 DAG 写回 *.gout（或 *.txt）格式
# --------------------------------------------------------------
def write_dag(out_path: str,
              n: int,
              src: List[int],
              dst: List[int],
              removed: Set[int]) -> None:
    """写出删除若干边后得到的 DAG，保持原始 (n m) + edge 列表的格式。"""
    remaining = [(u, v) for eid, (u, v) in enumerate(zip(src, dst)) if eid not in removed]
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"{n} {len(remaining)}\n")
        for u, v in remaining:
            f.write(f"{u} {v}\n")


# --------------------------------------------------------------
# 5️⃣ 主流程
# --------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Exact Minimum Feedback Arc Set (ILP) "
                    "with PageRank‑FAS fallback (OR‑Tools CBC)."
    )
    parser.add_argument("-i", "--input", required=True,
                        help="Folder containing *.txt or *.gout graphs")
    parser.add_argument("-o", "--output", required=True,
                        help="Folder where the resulting *.gout files will be saved")
    parser.add_argument("-t", "--timelimit", type=int, default=30,
                        help="Time limit per instance in seconds (0 = no limit). "
                             "Default 30 s – sufficient for graphs ≤ 100 vertices.")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Print detailed logs")
    args = parser.parse_args()

    in_dir = os.path.abspath(args.input)
    out_dir = os.path.abspath(args.output)
    os.makedirs(out_dir, exist_ok=True)

    # 支持 .txt 与 .gout 两种后缀
    files = [f for f in os.listdir(in_dir)
             if f.lower().endswith(".txt") or f.lower().endswith(".gout")]
    if not files:
        print(f"[Error] No *.txt or *.gout files found in {in_dir}")
        sys.exit(1)

    total_start = time.time()
    for fname in files:
        in_path = os.path.join(in_dir, fname)
        base = os.path.splitext(fname)[0]   # 去掉原后缀
        out_path = os.path.join(out_dir, f"{base}.gout")

        if args.verbose:
            print(f"\n=== Processing {fname} ===")

        # ------------------- 读取 -------------------
        try:
            n, src, dst = read_graph(in_path)
        except Exception as exc:
            print(f"[Error] Failed to read {fname}: {exc}")
            continue

        # ------------------- PageRank‑FAS warm‑start -------------------
        warm = pagerank_fas(n, src, dst, pr_iters=15)

        # ------------------- 求解 ILP -------------------
        removed_set, solved_opt = solve_min_fas_ilp(
            n, src, dst,
            timelimit=args.timelimit,
            warm_start=warm,
            verbose=args.verbose,
        )

        if not solved_opt:
            if args.verbose:
                print("  ILP did NOT finish optimal/feasible → using warm‑start result")
        else:
            if args.verbose:
                print("  ILP solved (optimal or feasible)")

        # ------------------- 写出 DAG -------------------
        try:
            write_dag(out_path, n, src, dst, removed_set)
        except Exception as exc:
            print(f"[Error] Failed to write result for {fname}: {exc}")
            continue

        if args.verbose:
            print(f"  Original edges : {len(src)}")
            print(f"  Deleted edges  : {len(removed_set)}")
            print(f"  Remaining edges: {len(src) - len(removed_set)}")
            print(f"  Output written to {out_path}")
        else:
            print(f"{fname} → {os.path.basename(out_path)}  (removed {len(removed_set)})")

    total_elapsed = time.time() - total_start
    print(f"\nAll done. Total elapsed: {total_elapsed:.2f}s")


if __name__ == "__main__":
    main()
