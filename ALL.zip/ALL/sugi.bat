python D:\System\Ftree\Vscode\ends_mycurrent\ALL\pr.py -i "D:\System\Ftree\Vscode\ends_mycurrent\ALL\input" -o "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in1_2" -t 5 -v

python ends_mycurrent\ALL\mml.py -i "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in1_2" -o "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in2_3" -v

python ends_mycurrent\ALL\upv.py -i "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in2_3" -o "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in2_3_1"

python ends_mycurrent\ALL\newbery.py -i "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in2_3_1" -o "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in2_3_2"

python ends_mycurrent\ALL\mnsb_ts.py -i "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in2_3_2" -o "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in3_4" --max_iter 5000  --time_limit 2 --allow_duplicate

python ends_mycurrent\ALL\vis.py -i "D:\System\Ftree\Vscode\ends_mycurrent\ALL\in3_4" -o "D:\System\Ftree\Vscode\ends_mycurrent\ALL\output"