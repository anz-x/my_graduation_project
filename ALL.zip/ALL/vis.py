#!/usr/bin/env python3
# -*- coding: utf-8 -*-

""" batch‑draw layered directed graphs from .txt → .jpg """
import os
import re
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Iterable

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

# ----------------------------------------------------------------------
# 1. 读取并解析单个 txt
# ----------------------------------------------------------------------
def parse_txt(filepath: Path) -> Tuple[int, int, List[Tuple[int, int]], Dict[int, List[int]]]:
    with filepath.open("r", encoding="utf-8") as f:
        raw = [ln.strip() for ln in f if ln.strip() != ""]

    n, m = map(int, raw[0].split())
    edges = [tuple(map(int, raw[i].split())) for i in range(1, 1 + m)]

    layer_pat = re.compile(r"Layer\s+(\d+)\s*:\s*(.*)")
    layers: Dict[int, List[int]] = {}
    for line in raw[1 + m:]:
        mobj = layer_pat.match(line)
        if not mobj:
            continue
        lid = int(mobj.group(1))
        nodes = [int(tok) for tok in mobj.group(2).split()] if mobj.group(2).strip() else []
        layers[lid] = nodes
    return n, m, edges, layers


# ----------------------------------------------------------------------
# 2. 为所有节点生成坐标（包括未在层里出现的节点）
# ----------------------------------------------------------------------
def compute_positions(
    layers: Dict[int, List[int]],
    all_nodes: Iterable[int],
    x_spacing: float = 2.0,
    y_spacing: float = 2.0,
) -> Dict[int, Tuple[float, float]]:
    pos: Dict[int, Tuple[float, float]] = {}
    sorted_layers = sorted(layers)

    for layer_idx in sorted_layers:
        for i, node in enumerate(layers[layer_idx]):
            pos[node] = (i * x_spacing, -layer_idx * y_spacing)

    # 处理没有显式层信息的节点
    missing = set(all_nodes) - set(pos.keys())
    if missing:
        new_layer = (max(sorted_layers) + 1) if sorted_layers else 0
        for i, node in enumerate(sorted(missing)):
            pos[node] = (i * x_spacing, -new_layer * y_spacing)

    return pos


# ----------------------------------------------------------------------
# 3. Matplotlib 绘图（手动层布局）
# ----------------------------------------------------------------------
def draw_with_matplotlib(G: nx.DiGraph,
                         pos: Dict[int, Tuple[float, float]],
                         layers: Dict[int, List[int]],
                         out_path: Path) -> None:
    # ---------- 1️⃣ 颜色 ----------
    cmap = plt.get_cmap("tab20")                     # 兼容 Matplotlib 3.7+（已改写）
    max_layer = max(layers.keys()) if layers else 0
    layer_color = {i: cmap(i % 20) for i in range(max_layer + 1)}

    # ---------- 2️⃣ 节点颜色 ----------
    node_to_layer = {}
    for lid, nodes in layers.items():
        for n in nodes:
            node_to_layer[n] = lid

    node_colors = [layer_color.get(node_to_layer.get(n), "#dddddd") for n in G.nodes()]

    # ---------- 3️⃣ 绘图 ----------
    plt.figure(figsize=(max(8, len(G) * 0.5), max(6, (max_layer + 1) * 1.2)))

    # ① 画节点
    nx.draw_networkx_nodes(G, pos,
                           node_color=node_colors,
                           node_size=800,
                           edgecolors="k",
                           linewidths=1.0)

    # ② 画有向边（关键参数）
    nx.draw_networkx_edges(G, pos,
                           arrows=True,                 # <‑‑ 必须打开
                           arrowstyle="-|>",           # 形状：实心三角
                           arrowsize=20,               # 大小（可自行调大/小）
                           connectionstyle="arc3,rad=0.1",  # 让相邻/平行边稍微弧化，防止重叠
                           edge_color="#555555",
                           width=1.2)

    # ③ 画标签
    nx.draw_networkx_labels(G, pos,
                           font_size=10,
                           font_color="black",
                           verticalalignment="center",
                           horizontalalignment="center")

    plt.axis("off")
    plt.tight_layout()
    plt.savefig(str(out_path), format="jpg", dpi=300)
    plt.close()



# ----------------------------------------------------------------------
# 4. 选用 GraphViz 完全排版（-g 参数时走这里）
# ----------------------------------------------------------------------
def draw_using_graphviz(edges: List[Tuple[int, int]],
                        layers: Dict[int, List[int]],
                        out_path: Path) -> None:
    import pydot

    g = pydot.Dot(graph_type="digraph", rankdir="TB")

    # 为每层创建子图并声明 rank=same（让同层结点共线）
    for lid, nodes in layers.items():
        sub = pydot.Subgraph()
        sub.set_rank("same")
        for n in nodes:
            node = pydot.Node(str(n), shape="circle", style="filled",
                              fillcolor="#ffaaaa", fontcolor="black")
            g.add_node(node)      # 必须加入全局图，否则孤立结点会消失
            sub.add_node(node)
        g.add_subgraph(sub)

    # 可能有未在任何层出现的结点
    all_nodes = {u for u, _ in edges} | {v for _, v in edges}
    defined = {n for lst in layers.values() for n in lst}
    for n in sorted(all_nodes - defined):
        node = pydot.Node(str(n), shape="circle", style="filled",
                          fillcolor="#dddddd", fontcolor="black")
        g.add_node(node)

    # 加边
    for u, v in edges:
        g.add_edge(pydot.Edge(str(u), str(v)))

    # 直接写 jpg（pydot 会内部调用 dot -Tjpg）
    g.write(str(out_path), format="jpg")


# ----------------------------------------------------------------------
# 5. 主循环：遍历文件夹 → 解析 → 绘图 → 保存
# ----------------------------------------------------------------------
def process_folder(in_dir: Path, out_dir: Path, use_graphviz: bool = False) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    txt_files = list(in_dir.glob("*.txt"))
    if not txt_files:
        print(f"[!] {in_dir} 中未找到 .txt 文件")
        return

    for txt_path in txt_files:
        n, m, edges, layers = parse_txt(txt_path)

        G = nx.DiGraph()
        G.add_nodes_from(range(n))
        G.add_edges_from(edges)

        out_path = out_dir / (txt_path.stem + ".jpg")
        if use_graphviz:
            draw_using_graphviz(edges, layers, out_path)
        else:
            pos = compute_positions(layers, G.nodes())          # <‑‑ 改这里
            draw_with_matplotlib(G, pos, layers, out_path)

        print(f"[✔] {txt_path.name} → {out_path.name}")


# ----------------------------------------------------------------------
# 6. 命令行入口
# ----------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description="把 txt 描述的有向分层图批量渲染为 jpg"
    )
    parser.add_argument("-i", "--input", type=Path, required=True,
                        help="输入文件夹（包含 .txt）")
    parser.add_argument("-o", "--output", type=Path, required=True,
                        help="输出文件夹（生成 .jpg）")
    parser.add_argument("-g", "--graphviz", action="store_true",
                        help="使用 GraphViz 排版（需要系统安装 graphviz）")
    args = parser.parse_args()
    process_folder(args.input, args.output, use_graphviz=args.graphviz)


if __name__ == "__main__":
    main()
