#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
MML (Min+MaxLength) layered drawing → plain‑text output
-----------------------------------------------------

* Input  : folder containing *.txt (or *.gout) files.
            每行:  n m
                  u v
                  …
  (顶点编号 0‑based，图可以是任意有向图，MML 也会把必要的反向边计入层次)

* Model  : OR‑Tools Mixed‑Integer Program (CBC) – 论文中的 MML 变体
           (不产生 dummy 顶点，只求最小化  w_rev·#reversed  +  w_len·∑|Δlayer|).

* Output : for each input file, a *.txt 文件，格式：

    n m
    u1 v1
    …
    um vm
    k                # 层数 (= max_layer+1)
    nodeIDs_of_layer0
    nodeIDs_of_layer1
    …
    nodeIDs_of_layer(k‑1)

  每层的节点已按升序排列（若你想保留其它顺序，只改 `forward_lists.sort()` 那行即可）。

使用方式
---------
    python3 mml_layering_to_txt.py -i ./dag_folder -o ./layered_folder -v

可选参数
---------
    -r, --w_rev   : 反向边在目标函数中的权重（默认 1）
    -l, --w_len   : 边长在目标函数中的权重（默认 1）
    -k, --timelimit: 每个实例的求解时间上限（秒），0=不限制
    -v, --verbose : 打印详细日志
"""

import argparse
import os
import sys
import time
from collections import deque
from typing import List, Tuple, Dict

# ----------------------------------------------------------------------
# 1️⃣ 读取图文件（*.txt 或 *.gout，格式相同）
# ----------------------------------------------------------------------
def read_dag(path: str) -> Tuple[int, List[int], List[int]]:
    """
    读取 “n m\\n u v …” 的有向图文件（后缀 .txt/.gout）。
    返回 (n, src, dst)。
    """
    with open(path, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]

    if not lines:
        raise ValueError(f"Empty file: {path}")

    n_str, m_str = lines[0].split()
    n, m = int(n_str), int(m_str)

    src, dst = [], []
    for i, line in enumerate(lines[1:], start=1):
        u_str, v_str = line.split()
        u, v = int(u_str), int(v_str)
        if not (0 <= u < n and 0 <= v < n):
            raise ValueError(f"Vertex index out of range at line {i+1} in {path}")
        src.append(u)
        dst.append(v)

    if len(src) != m:
        raise ValueError(f"Declared m={m} but actually found {len(src)} edges in {path}")

    return n, src, dst


# ----------------------------------------------------------------------
# 2️⃣ 拓扑序（可选，用来得到更紧的 H 上界）
# ----------------------------------------------------------------------
def topological_order(n: int, src: List[int], dst: List[int]) -> List[int]:
    """Kahn 算法返回任意拓扑序；若图不是 DAG 抛异常。"""
    indeg = [0] * n
    adj = [[] for _ in range(n)]
    for u, v in zip(src, dst):
        indeg[v] += 1
        adj[u].append(v)

    q = deque([v for v in range(n) if indeg[v] == 0])
    order = []
    while q:
        u = q.popleft()
        order.append(u)
        for w in adj[u]:
            indeg[w] -= 1
            if indeg[w] == 0:
                q.append(w)

    if len(order) != n:
        raise ValueError("Input graph is not a DAG")
    return order


def longest_path_height(n: int, src: List[int], dst: List[int]) -> int:
    """返回 DAG 最小可能层数 = (最长路径长度) + 1。"""
    order = topological_order(n, src, dst)
    dp = [0] * n
    pred = [[] for _ in range(n)]
    for u, v in zip(src, dst):
        pred[v].append(u)

    for v in order:
        if pred[v]:
            dp[v] = max(dp[p] + 1 for p in pred[v])
    return max(dp) + 1


# ----------------------------------------------------------------------
# 3️⃣ MML MIP（OR‑Tools CBC）
# ----------------------------------------------------------------------
def solve_mml(
    n: int,
    src: List[int],
    dst: List[int],
    w_rev: int = 1,
    w_len: int = 1,
    time_limit: int = 0,
    verbose: bool = False,
) -> Tuple[List[int], List[int]]:
    """
    对有向图求解 MML（Min+MaxLength）模型。

    返回
    ----
    layer_of[v]      : 0‑based 层号
    rev_edge_ids    : 反向边的全局 id（可选用于后处理）
    """
    from ortools.linear_solver import pywraplp

    # H 为层号的上界。这里直接取最宽的 n，亦可改为 longest_path_height(...)
    H = n
    M = H                     # big‑M，足够大

    solver = pywraplp.Solver.CreateSolver("CBC_MIXED_INTEGER_PROGRAMMING")
    if solver is None:
        raise RuntimeError("Failed to create CBC solver (check OR‑Tools installation)")

    # ---------- 变量 ----------
    L = [solver.IntVar(0, H - 1, f"L_{v}") for v in range(n)]

    m = len(src)
    r = [solver.BoolVar(f"r_{e}") for e in range(m)]         # 1 → 反向
    length = [solver.IntVar(0, H, f"len_{e}") for e in range(m)]

    # ---------- 约束 ----------
    for e, (u, v) in enumerate(zip(src, dst)):
        # (1) 方向约束：forward (r=0) 或 reverse (r=1)
        solver.Add(L[u] + 1 <= L[v] + M * r[e])
        solver.Add(L[v] + 1 <= L[u] + M * (1 - r[e]))

        # (2) 绝对层差 = |L[u] - L[v]|
        solver.Add(length[e] >= L[v] - L[u])
        solver.Add(length[e] >= L[u] - L[v])
        solver.Add(length[e] <= L[v] - L[u] + M * r[e])
        solver.Add(length[e] <= L[u] - L[v] + M * (1 - r[e]))

    # ---------- 目标 ----------
    obj = solver.Objective()
    for e in range(m):
        obj.SetCoefficient(r[e], w_rev)
        obj.SetCoefficient(length[e], w_len)
    obj.SetMinimization()

    if time_limit > 0:
        solver.SetTimeLimit(time_limit * 1000)   # ms

    if verbose:
        print(f"  ---- Solving MML ----  n={n}, m={m}, H={H}")
        print(f"  Weights: rev={w_rev}, len={w_len}")

    status = solver.Solve()

    # ---------- 状态打印（兼容所有 OR‑Tools 版本） ----------
    if verbose:
        status_str = {
            solver.OPTIMAL:    "OPTIMAL",
            solver.FEASIBLE:   "FEASIBLE",
            solver.INFEASIBLE:"INFEASIBLE",
            solver.UNBOUNDED:  "UNBOUNDED",
            solver.ABNORMAL:  "ABNORMAL",
            solver.NOT_SOLVED:"NOT_SOLVED"
        }.get(status, "UNKNOWN")
        print(f"  Solver status: {status} ({status_str})")
        print(f"  Objective value: {obj.Value()}")

    # ---------- 求解失败回退 ----------
    if status not in (solver.OPTIMAL, solver.FEASIBLE):
        if verbose:
            print("  MIP 求解失败，使用最长路径自然层叠（不产生反向边）作为回退方案")
        # longest‑path natural layering
        order = topological_order(n, src, dst)
        dp = [0] * n
        pred = [[] for _ in range(n)]
        for u, v in zip(src, dst):
            pred[v].append(u)
        for v in order:
            if pred[v]:
                dp[v] = max(dp[p] + 1 for p in pred[v])
        return dp, []    # 没有反向边

    # ---------- 提取解 ----------
    layer_of = [int(L[v].solution_value()) for v in range(n)]
    rev_edge_ids = [e for e in range(m) if int(r[e].solution_value()) == 1]

    return layer_of, rev_edge_ids


# ----------------------------------------------------------------------
# 4️⃣ 把层号写成要求的 plain‑text 格式
# ----------------------------------------------------------------------
def write_layered_txt(
    out_path: str,
    n: int,
    src: List[int],
    dst: List[int],
    layer_of: List[int],
) -> None:
    """
    生成如下文件：

        n m
        u1 v1
        …
        um vm
        k                # 层数 = max(layer_of)+1
        nodeIDs_of_layer0   (空格分隔，已升序)
        nodeIDs_of_layer1
        …
        nodeIDs_of_layer(k-1)

    若某层为空（理论上不会出现），输出空行。
    """
    k = max(layer_of) + 1
    layers: List[List[int]] = [[] for _ in range(k)]
    for v, lev in enumerate(layer_of):
        layers[lev].append(v)

    # 为了“已经排列好”，我们把每层的节点按升序排列
    for lst in layers:
        lst.sort()

    with open(out_path, "w", encoding="utf-8") as fout:
        # 顶点数、边数
        fout.write(f"{n} {len(src)}\n")
        # 原始边（保持原文件顺序）
        for u, v in zip(src, dst):
            fout.write(f"{u} {v}\n")
        # 层数
        fout.write(f"{k}\n")
        # 每层节点列表
        for lst in layers:
            if lst:
                fout.write(" ".join(str(v) for v in lst) + "\n")
            else:
                fout.write("\n")   # 空层，写一个空行


# ----------------------------------------------------------------------
# 5️⃣ 主程序
# ----------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description="MML layered drawing – read *.txt/*.gout, write layered *.txt"
    )
    parser.add_argument("-i", "--input", required=True,
                        help="Folder containing input *.txt (or *.gout) DAG files")
    parser.add_argument("-o", "--output", required=True,
                        help="Folder where layered *.txt files will be written")
    parser.add_argument("-r", "--w_rev", type=int, default=1,
                        help="Weight of a reversed edge in the objective (default 1)")
    parser.add_argument("-l", "--w_len", type=int, default=1,
                        help="Weight of edge length |Δlayer| in the objective (default 1)")
    parser.add_argument("-k", "--timelimit", type=int, default=0,
                        help="Maximum solving time per instance (seconds, 0 = no limit)")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Print detailed progress information")
    args = parser.parse_args()

    input_dir = os.path.abspath(args.input)
    output_dir = os.path.abspath(args.output)
    os.makedirs(output_dir, exist_ok=True)

    # 支持 .txt 与 .gout 两种后缀
    candidates = [f for f in os.listdir(input_dir)
                  if f.lower().endswith(".txt") or f.lower().endswith(".gout")]
    if not candidates:
        print(f"[Error] No *.txt or *.gout files found in {input_dir}")
        sys.exit(1)

    total_start = time.time()
    for fname in candidates:
        in_path = os.path.join(input_dir, fname)
        base_name = os.path.splitext(fname)[0]          # 去掉原后缀
        out_path = os.path.join(output_dir, f"{base_name}.txt")

        if args.verbose:
            print(f"\n=== Processing {fname} ===")

        try:
            n, src, dst = read_dag(in_path)
        except Exception as exc:
            print(f"[Error] Failed to read {fname}: {exc}")
            continue

        # ---------- 求解 ----------
        start = time.time()
        layer_of, rev_edges = solve_mml(
            n,
            src,
            dst,
            w_rev=args.w_rev,
            w_len=args.w_len,
            time_limit=args.timelimit,
            verbose=args.verbose,
        )
        elapsed = time.time() - start

        # ---------- 写文件 ----------
        try:
            write_layered_txt(out_path, n, src, dst, layer_of)
        except Exception as exc:
            print(f"[Error] Failed to write result for {fname}: {exc}")
            continue

        if args.verbose:
            print(f"  Layers used : {max(layer_of)+1}")
            print(f"  Reversed edges (in model) : {len(rev_edges)}")
            print(f"  Solving time: {elapsed:.2f}s")
            print(f"  Output written to {out_path}")
        else:
            print(f"{fname} → {os.path.basename(out_path)}  (layers={max(layer_of)+1})")

    total_elapsed = time.time() - total_start
    print(f"\nAll done. Total elapsed: {total_elapsed:.2f}s")


if __name__ == "__main__":
    main()
