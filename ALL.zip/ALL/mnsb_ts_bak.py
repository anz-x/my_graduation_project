#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Fast MNSB‑TS (Multiple‑Neighbourhood Solution‑Based Tabu Search)

* 支援跨層邊（會自動在每條跨層邊之間插入 dummy 節點，使所有弧只跨相鄰層）  
* 使用隨機抽樣的鄰域、提前終止以及多次隨機重啟，對中小規模圖（數十‑數百節點）只需毫秒級  
* 輸入/輸出皆為 .txt，保留原始 n、m 與完整邊列表，**不會遺失任何邊**  
* 若同一節點 ID 在多層出現，請加上 `--allow_duplicate`（會把每次出現視為不同節點）
"""

import os
import argparse
import random
import time
import re
import sys
from typing import List, Dict, Tuple

# ----------------------------------------------------------------------
# 1.  Graph data structure (txt I/O + dummy‑edge expansion)
# ----------------------------------------------------------------------


class IncrementalLayeredGraph:
    """
    保存：
        * 原始 n、m、完整邊表 (original_edges)
        * layers (含 dummy) – 每層的全局 ID 列表，已排好順序
        * forward_edges – 只保留相鄰層的弧 (dummy 讓所有弧都相鄰)
        * vertex_to_loc – 全局 ID → [(layer, local_index), …] 的映射
          (若同一 ID 在多層出現，會有多個 tuple)
    """

    def __init__(
        self,
        original_n: int,
        original_m: int,
        original_edges: List[Tuple[int, int]],
        layers_nodes: List[List[int]],
        forward_edges: List[List[List[int]]],
        vertex_to_loc: Dict[int, List[Tuple[int, int]]],
    ):
        self.original_n = original_n
        self.original_m = original_m
        self.original_edges = original_edges[:]            # 完整的 (src, dst) 列表

        self.layers = layers_nodes                        # 包含 dummy 的層序
        self.forward_edges = forward_edges                # 只保留相鄰層的弧
        self.K = len(self.layers)

        self.layer_node_num = [len(l) for l in self.layers]
        self.layer_old_node_num = self.layer_node_num[:]   # 所有節點均視為「原始」(dummy 也算)

        self.vertex_to_loc = vertex_to_loc               # 全局 ID → [(layer, local), ...]

    # ------------------------------------------------------------------
    # 讀取 txt ---------------------------------------------------------
    # ------------------------------------------------------------------
    @staticmethod
    def load_from_txt(path: str, allow_duplicate: bool = False) -> "IncrementalLayeredGraph":
        """
        txt 必須符合以下格式（與說明文件一致）：

        n m
        u1 v1
        u2 v2
        …
        （可選空行）
        Layer0NodeId0 Layer0NodeId1 …
        Layer1NodeId0 …
        …
        """
        with open(path, "r", encoding="utf-8") as f:
            raw = [ln.strip() for ln in f if ln.strip() != ""]

        if not raw:
            raise ValueError("Empty input file")

        # 第 1 行：n m
        first = re.split(r"[\s,]+", raw[0])
        if len(first) < 2:
            raise ValueError("First line must contain n and m")
        n, m = map(int, first[:2])

        # 接下來 m 行是弧
        edges: List[Tuple[int, int]] = []
        for i in range(1, 1 + m):
            u, v = map(int, re.split(r"[\s,]+", raw[i]))
            edges.append((u, v))

        # 剩餘行是層序
        layer_lines = raw[1 + m:]
        layers_nodes: List[List[int]] = []
        for line in layer_lines:
            nums = [int(x) for x in re.split(r"[\s,]+", line) if x != ""]
            if not nums:
                continue
            layers_nodes.append(nums)

        K = len(layers_nodes)
        if K == 0:
            raise ValueError("No layer information found")

        # 建立 vertex_to_loc（允許同一 ID 在多層）
        vertex_to_loc: Dict[int, List[Tuple[int, int]]] = {}
        for k, layer in enumerate(layers_nodes):
            for local_idx, v in enumerate(layer):
                vertex_to_loc.setdefault(v, []).append((k, local_idx))

        # 若不允許 duplicate 且有重複，直接拋錯
        if not allow_duplicate:
            dup = [v for v, occ in vertex_to_loc.items() if len(occ) > 1]
            if dup:
                raise ValueError(
                    f"Duplicate vertex IDs detected in layers (use --allow_duplicate to ignore): {sorted(dup)}"
                )

        # ------------------------------------------------------------------
        # 2) 把所有跨層邊拆成相鄰層的多段（插入 dummy 節點）
        # ------------------------------------------------------------------
        # 先找出每個原始頂點所在層
        vertex_layer: Dict[int, int] = {}
        for k, layer in enumerate(layers_nodes):
            for v in layer:
                vertex_layer[v] = k

        # dummy 產生器 – 從 max(original IDs) + 1 開始
        dummy_counter = max(vertex_layer.keys()) + 1

        # 為每層建立 forward list（長度 = 本層節點數），稍後會隨 dummy 增長而動態擴充
        forward_edges: List[List[List[int]]] = [
            [[] for _ in range(len(layers_nodes[k]))] for k in range(K - 1)
        ]

        # 逐條原始邊做展開
        for u, v in edges:
            if u not in vertex_layer or v not in vertex_layer:
                # 端點不在層序裡的弧保留在 original_edges 中（不參與 crossing）
                continue
            lu = vertex_layer[u]
            lv = vertex_layer[v]

            # 若已相鄰，直接放入 forward_edges
            if lv == lu + 1:
                # 找 u 在層 lu 的局部索引
                for lay, loc in vertex_to_loc[u]:
                    if lay == lu:
                        forward_edges[lu][loc].append(v)
                        break
                continue

            # ---- 跨層：在 (lu+1 .. lv-1) 之間插入 dummy ----
            prev = u
            prev_layer = lu
            for inter in range(lu + 1, lv):
                dummy_id = dummy_counter
                dummy_counter += 1

                # 把 dummy 加入對應層的節點列表
                layers_nodes[inter].append(dummy_id)
                vertex_to_loc.setdefault(dummy_id, []).append((inter, len(layers_nodes[inter]) - 1))

                # 若該層不是最後層，必須為 dummy 建立 forward_edges 列表
                if inter < K - 1:
                    forward_edges[inter].append([])   # 新增空的 outgoing 列表

                # prev (could be original or dummy) → dummy
                for lay, loc in vertex_to_loc[prev]:
                    if lay == prev_layer:
                        # 保證 forward_edges[prev_layer] 已有足夠的槽位
                        # 若 prev 為 dummy，該層的 forward_edges 也會在前面已擴充
                        forward_edges[prev_layer][loc].append(dummy_id)
                        break

                # 更新 for 下一段迭代
                prev = dummy_id
                prev_layer = inter

            # 最後一段：最後的 dummy → v
            for lay, loc in vertex_to_loc[prev]:
                if lay == prev_layer:
                    forward_edges[prev_layer][loc].append(v)
                    break

        return IncrementalLayeredGraph(
            original_n=n,
            original_m=m,
            original_edges=edges,
            layers_nodes=layers_nodes,
            forward_edges=forward_edges,
            vertex_to_loc=vertex_to_loc,
        )

    # ------------------------------------------------------------------
    # 常用工具
    # ------------------------------------------------------------------
    def layer_size(self, k: int) -> int:
        return len(self.layers[k])

    def layer_old_size(self, k: int) -> int:
        return len(self.layers[k])

    def outgoing(self, k: int, u_local: int) -> List[int]:
        """返回層 k 中局部下標 u_local 的所有相鄰層目標（全局 ID）"""
        if k >= self.K - 1:
            return []
        return self.forward_edges[k][u_local]

    def get_local_index(self, k: int, global_id: int) -> int:
        """取得在層 k 中的局部下標。如果同一 global_id 在多層出現，必須明確指出層 k"""
        occ = self.vertex_to_loc.get(global_id, [])
        for layer, local in occ:
            if layer == k:
                return local
        raise KeyError(f"Vertex {global_id} not found in layer {k}")

    # ------------------------------------------------------------------
    # 輸出 txt（保持原始 n,m 與完整邊列表）-------------------------
    # ------------------------------------------------------------------
    def write_solution_txt(self, ordering: List[List[int]], path: str) -> None:
        """
        輸出格式：

            n m
            u1 v1
            u2 v2
            …
            (空行)
            Layer 0: x0_1 x0_2 …
            Layer 1: x1_1 …
            …
        """
        lines: List[str] = [f"{self.original_n} {self.original_m}"]
        for u, v in self.original_edges:
            lines.append(f"{u} {v}")
        lines.append("")                     # 空行分隔

        for i, layer in enumerate(ordering):
            lines.append(f"Layer {i}: " + " ".join(map(str, layer)))

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))


# ----------------------------------------------------------------------
# 2.  Fenwick (Binary Indexed Tree) & inversion counting
# ----------------------------------------------------------------------


class Fenwick:
    """1‑based Fenwick tree (Binary Indexed Tree)"""

    def __init__(self, n: int):
        self.n = n
        self.bit = [0] * (n + 1)

    def add(self, idx: int, delta: int = 1):
        i = idx
        while i <= self.n:
            self.bit[i] += delta
            i += i & -i

    def sum(self, idx: int) -> int:
        s = 0
        i = idx
        while i > 0:
            s += self.bit[i]
            i -= i & -i
        return s


def count_inversions(arr: List[int]) -> int:
    """返回序列 arr（值 0 … m‑1）中的逆序對數"""
    if not arr:
        return 0
    m = max(arr) + 1
    ft = Fenwick(m)
    inv = 0
    for i, v in enumerate(arr):
        seen_le_v = ft.sum(v + 1)          # 已出現 ≤ v 的個數（1‑based）
        inv += i - seen_le_v
        ft.add(v + 1, 1)
    return inv


# ----------------------------------------------------------------------
# 3.  Solution (stores ordering, crossing count, hashing)
# ----------------------------------------------------------------------


class Solution:
    """保存每層的排列、提供交叉計算、提供 64‑bit 哈希（用於 tabu）"""

    def __init__(self, ordering: List[List[int]], graph: IncrementalLayeredGraph):
        self.order = [list(l) for l in ordering]    # 深拷貝
        self.graph = graph
        self._crossings: int = -1                    # lazy cache

    # ------------------------------------------------------------------
    # 哈希 – solution‑based tabu 使用
    # ------------------------------------------------------------------
    def hash(self) -> int:
        """FNV‑1a 64‑bit 哈希，對完整排列唯一映射"""
        h = 14695981039346656037
        for layer in self.order:
            for v in layer:
                h ^= v
                h *= 1099511628211
                h &= (1 << 64) - 1
        return h

    # ------------------------------------------------------------------
    # 交叉計算（只考慮相鄰層的弧，已經把長邊拆成相鄰邊，故完整捕捉所有交叉）
    # ------------------------------------------------------------------
    def crossing_number(self) -> int:
        if self._crossings >= 0:
            return self._crossings

        total = 0
        K = self.graph.K
        for k in range(K - 1):
            src_order = self.order[k]
            dst_order = self.order[k + 1]

            # 目標層中每個頂點的排位（全局 ID → 位置）
            pos_dst = {v: i for i, v in enumerate(dst_order)}

            targets = []
            for u_global in src_order:
                try:
                    u_local = self.graph.get_local_index(k, u_global)
                except KeyError:
                    continue                 # 理論上不會發生
                for v_global in self.graph.outgoing(k, u_local):
                    idx = pos_dst.get(v_global)
                    if idx is not None:
                        targets.append(idx)

            total += count_inversions(targets)

        self._crossings = total
        return total

    # ------------------------------------------------------------------
    # 複製、層更新（在鄰域搜索中使用）
    # ------------------------------------------------------------------
    def deepcopy(self) -> "Solution":
        return Solution([list(l) for l in self.order], self.graph)

    def set_layer(self, k: int, new_order: List[int]):
        self.order[k] = new_order
        self._crossings = -1                     # 失效緩存


# ----------------------------------------------------------------------
# 4.  Fast MNSB‑TS（隨機抽樣鄰域 + 提前終止）
# ----------------------------------------------------------------------


class FastMNSBTS:
    """
    主要加速措施：

    * 每輪僅抽樣 `sample_size` 個隨機鄰居（而不是全列舉）。
    * 若 `max_no_imp` 次連續沒有找到更好解則提前結束本次重啟。
    * 仍支援四個基礎鄰域 (N1‑N4) + 跨層交換 N5。
    * 多次隨機重啟（外層 loop 控制）提升全局搜索品質。
    """

    def __init__(
        self,
        graph: IncrementalLayeredGraph,
        max_iter: int = 200_000,
        time_limit: float = 200.0,
        seed: int = 0,
        sample_size: int = 100,
        max_no_imp: int = 5_000,
    ):
        self.graph = graph
        self.max_iter = max_iter
        self.time_limit = time_limit
        self.random = random.Random(seed)

        self.sample_size = sample_size          # 每輪抽樣的候選解數
        self.max_no_imp = max_no_imp            # 連續無改進的上限

        # 參數（已放寬）
        self.l_min_ratio = 0.10
        self.l_max_ratio = 0.30
        self.Theta_factor = 45
        self.xi_max = 10_000
        self.tabu_tenure = 7

        # Θ 與 θ1‑θ4：全部設定為 Θ（放寬搜索）
        n_total = sum(self.graph.layer_size(k) for k in range(self.graph.K))
        self.Theta = int(self.Theta_factor * n_total)
        self.tmax = 5                         # 四個基礎 + N5
        self.theta = [self.Theta] * self.tmax

    # ------------------------------------------------------------------
    # 1) 初始解（直接使用讀入的層序作為起點）
    # ------------------------------------------------------------------
    def _initial_solution(self) -> Solution:
        return Solution([layer[:] for layer in self.graph.layers], self.graph)

    # ------------------------------------------------------------------
    # 2) 隨機抽樣產生鄰居（四個基礎 + N5）
    # ------------------------------------------------------------------
    def _sample_moves(self, typ: int, cur_sol: Solution) -> List[Solution]:
        K = self.graph.K
        candidates: List[Solution] = []

        if typ == 1:                # N1 – 把單個節點插入同層的另一位置
            for _ in range(self.sample_size):
                k = self.random.randrange(K)
                L = len(self.graph.layers[k])
                if L < 2:
                    continue
                src = self.random.randrange(L)
                dst = self.random.randrange(L)
                if src == dst:
                    continue
                new_layer = cur_sol.order[k][:]
                node = new_layer.pop(src)
                new_layer.insert(dst, node)
                new_sol = cur_sol.deepcopy()
                new_sol.set_layer(k, new_layer)
                candidates.append(new_sol)

        elif typ == 2:              # N2 – 同層交換兩個節點
            for _ in range(self.sample_size):
                k = self.random.randrange(K)
                L = len(self.graph.layers[k])
                if L < 2:
                    continue
                i, j = self.random.sample(range(L), 2)
                new_layer = cur_sol.order[k][:]
                new_layer[i], new_layer[j] = new_layer[j], new_layer[i]
                new_sol = cur_sol.deepcopy()
                new_sol.set_layer(k, new_layer)
                candidates.append(new_sol)

        elif typ == 3:              # N3 – 同 N1（保留以符合論文結構）
            return self._sample_moves(1, cur_sol)

        elif typ == 4:              # N4 – 同 N2（保留以符合論文結構）
            return self._sample_moves(2, cur_sol)

        elif typ == 5:              # N5 – 相鄰兩層之間的跨層交換
            for _ in range(self.sample_size):
                k = self.random.randrange(K - 1)          # 只取相鄰層
                src_layer = self.graph.layers[k]
                dst_layer = self.graph.layers[k + 1]
                if not src_layer or not dst_layer:
                    continue
                i = self.random.randrange(len(src_layer))
                j = self.random.randrange(len(dst_layer))
                new_src = cur_sol.order[k][:]
                new_dst = cur_sol.order[k + 1][:]
                new_src[i], new_dst[j] = new_dst[j], new_src[i]
                new_sol = cur_sol.deepcopy()
                new_sol.set_layer(k, new_src)
                new_sol.set_layer(k + 1, new_dst)
                candidates.append(new_sol)

        return candidates

    # ------------------------------------------------------------------
    # 3) 主迴圈（Tabu + 動態多樣化）
    # ------------------------------------------------------------------
    def run(self) -> Tuple[Solution, int]:
        start = time.time()
        cur_sol = self._initial_solution()
        best_sol = cur_sol.deepcopy()
        best_cross = best_sol.crossing_number()

        tabu_dict: Dict[int, int] = {}
        tabu_dict[best_sol.hash()] = 0

        no_imp_cnt = 0               # 連續無改進次數
        neigh_id = 1                 # 目前使用的鄰域 (1‑5)

        # 多樣化參數（刪除的頂點比例）
        total_inc = sum(
            self.graph.layer_size(k) - self.graph.layer_old_size(k)
            for k in range(self.graph.K)
        )
        l_min = max(1, int(self.l_min_ratio * total_inc))
        l_max = max(1, int(self.l_max_ratio * total_inc))
        l_cur = l_min

        iteration = 0
        while iteration < self.max_iter and (time.time() - start) < self.time_limit:
            iteration += 1

            # 1️⃣ 隨機抽樣候選解
            cand_list = self._sample_moves(neigh_id, cur_sol)
            if not cand_list:                     # 沒有可行候選（層過小）直接換鄰域
                neigh_id = neigh_id % self.tmax + 1
                continue

            # 2️⃣ 從候選中挑出最好的（考慮 tabu + aspiration）
            best_cand = None
            best_cand_cross = None
            for cand in cand_list:
                h = cand.hash()
                if tabu_dict.get(h, -1) > iteration:
                    if cand.crossing_number() >= best_cross:   # aspiration
                        continue
                cross = cand.crossing_number()
                if best_cand_cross is None or cross < best_cand_cross:
                    best_cand_cross = cross
                    best_cand = cand

            if best_cand is None:                # 所有候選被 tabu 且無改進 -> 換鄰域
                neigh_id = neigh_id % self.tmax + 1
                continue

            # 3️⃣ 接受最佳鄰居、寫入 tabu
            cur_sol = best_cand
            tabu_dict[cur_sol.hash()] = iteration + self.tabu_tenure

            # 4️⃣ 更新全局最佳
            if best_cand_cross < best_cross:
                best_cross = best_cand_cross
                best_sol = cur_sol.deepcopy()
                no_imp_cnt = 0
                neigh_id = 1
                l_cur = l_min
                if best_cross == 0:               # 已達理論最小，立即返回
                    break
            else:
                no_imp_cnt += 1

            # 5️⃣ 若當前鄰域的無改進次數 > θ，切換鄰域（令牌環）
            if no_imp_cnt > self.theta[neigh_id - 1]:
                neigh_id = neigh_id % self.tmax + 1
                no_imp_cnt = 0

            # 6️⃣ 若連續 `max_no_imp` 次都沒改進 → 動態多樣化
            if no_imp_cnt >= self.max_no_imp:
                cur_sol = self._diversify(best_sol, l_cur)
                no_imp_cnt = 0
                neigh_id = 1
                if l_cur < l_max:
                    l_cur = min(l_cur + 1, l_max)
                else:
                    l_cur = l_max

        return best_sol, best_cross

    # ------------------------------------------------------------------
    # 4) 動態多樣化（與原版相同，只是作為內部方法調用）
    # ------------------------------------------------------------------
    def _diversify(self, base_sol: Solution, l: int) -> Solution:
        new_sol = base_sol.deepcopy()
        for k in range(self.graph.K):
            layer = new_sol.order[k]
            if len(layer) <= l:
                continue
            to_remove = self.random.sample(layer, l)

            # 刪除
            cur = [v for v in layer if v not in to_remove]
            new_sol.set_layer(k, cur)

            # 貪心重新插回
            for v in to_remove:
                best_pos = None
                best_cross = None
                cur = new_sol.order[k]
                for pos in range(len(cur) + 1):
                    tmp = cur[:pos] + [v] + cur[pos:]
                    new_sol.set_layer(k, tmp)
                    cross = new_sol.crossing_number()
                    if best_cross is None or cross < best_cross:
                        best_cross = cross
                        best_pos = pos
                cur = new_sol.order[k]
                cur.insert(best_pos, v)
                new_sol.set_layer(k, cur)
        return new_sol


# ----------------------------------------------------------------------
# 5.  主程式 – 多重隨機重啟
# ----------------------------------------------------------------------
def process_one_file(in_path: str, args) -> None:
    # 讀取圖（自動把跨層邊展開成 dummy）
    g = IncrementalLayeredGraph.load_from_txt(
        in_path, allow_duplicate=args.allow_duplicate
    )

    best_overall: Solution = None
    best_cross_overall = None

    for restart in range(args.restarts):
        alg = FastMNSBTS(
            graph=g,
            max_iter=args.max_iter,
            time_limit=args.time_limit,
            seed=args.seed + restart,
            sample_size=args.samples,
            max_no_imp=args.max_no_imp,
        )
        sol, cross = alg.run()
        if best_cross_overall is None or cross < best_cross_overall:
            best_cross_overall = cross
            best_overall = sol

    # 寫回 txt（檔名保持原名，只是副檔名仍為 .txt）
    base_name = os.path.splitext(os.path.basename(in_path))[0] + ".txt"
    out_path = os.path.join(args.output_dir, base_name)
    g.write_solution_txt(best_overall.order, out_path)

    print(
        f"[{os.path.basename(in_path)}]  best_cross = {best_cross_overall}   →  {out_path}"
    )


def main():
    parser = argparse.ArgumentParser(
        description="Fast MNSB‑TS – minimise edge crossings of incremental layered graphs (txt I/O)"
    )
    parser.add_argument("-i", "--input_dir", required=True, help="Folder containing input *.txt* files")
    parser.add_argument("-o", "--output_dir", required=True, help="Folder to store output *.txt* files")
    parser.add_argument("--max_iter", type=int, default=200_000, help="Maximum iterations per restart")
    parser.add_argument(
        "--time_limit",
        type=float,
        default=200.0,
        help="Maximum runtime (seconds) per restart",
    )
    parser.add_argument("--seed", type=int, default=0, help="Base random seed")
    parser.add_argument(
        "--restarts", type=int, default=5, help="Number of independent random restarts"
    )
    parser.add_argument(
        "--samples",
        type=int,
        default=100,
        help="Number of random neighbour candidates evaluated each iteration",
    )
    parser.add_argument(
        "--max_no_imp",
        type=int,
        default=5000,
        help="Stop a restart after this many consecutive non‑improving iterations",
    )
    parser.add_argument(
        "--allow_duplicate",
        action="store_true",
        help="Permit the same vertex ID to appear in multiple layers (treated as distinct copies)",
    )
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    txt_files = [f for f in os.listdir(args.input_dir) if f.lower().endswith(".txt")]
    if not txt_files:
        print("No .txt files found in the input folder.", file=sys.stderr)
        sys.exit(1)

    for fn in txt_files:
        in_path = os.path.join(args.input_dir, fn)
        process_one_file(in_path, args)


if __name__ == "__main__":
    main()
