#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
layer_optimize.py

对指定文件夹中的 .txt 有向层次图进行局部层次调整，
以降低直线绘制时的边交叉数，并把结果写入另一个文件夹。

输入文件格式（示例）::

    10 9
    1 4
    2 4
    3 5
    4 6
    4 7
    5 6
    5 9
    7 9
    8 3
    4               # k – 层数
    0 1 2 8
    3 4
    5 7
    6 9

前两列是 n、m；随后 m 行是有向边；再一行是层数 k，随后 k 行给出每层的节点列表
（行内顺序即水平顺序）。脚本保持该顺序，只在必要时重新排序。

算法思路
-------
1. 读取文件 → (n, m, edges, layers)。
2. 采用贪心局部搜索：尝试把每个节点移动到所有 **合法** 的层，
   只接受能够 **严格减少交叉数** 的移动。
3. 在局部搜索结束后，对每层执行 barycenter 排序，以进一步降低交叉。
4. 删除空层、重新编号并写入输出文件，保持与输入相同的文本格式。

参考文献
--------
* Barth, W. & Mutzel, P. (2004). *Simple and Efficient Bilayer Cross Counting*.
  该工作把两层交叉计数转化为逆序对计数，提供 O(|E| log |V|) 的实现
  【5†L15-L23】【9†L0-L6】。
* Sugiyama, K. et al. (1981). *Layered Graph Drawing* – 经典的分层绘制框架，
  交叉最小化是 NP‑hard，常用启发式包括 barycenter/median
  【10†L52-L59】。
"""

import argparse
import os
from pathlib import Path
from typing import List, Tuple, Dict, Set


# ----------------------------------------------------------------------
# Ⅰ  I/O
# ----------------------------------------------------------------------
def read_graph(file_path: Path) -> Tuple[int, int, List[Tuple[int, int]], List[List[int]]]:
    """读取单个 .txt 文件，返回顶点数、边数、边列表、层次列表。"""
    with file_path.open("r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]

    n, m = map(int, lines[0].split())
    edges = []
    for i in range(1, 1 + m):
        u, v = map(int, lines[i].split())
        edges.append((u, v))

    k = int(lines[1 + m])                     # 层数
    layers = []
    for i in range(k):
        line = lines[2 + m + i]
        layer_nodes = list(map(int, line.split())) if line else []
        layers.append(layer_nodes)            # 保持输入顺序
    return n, m, edges, layers


def write_graph(file_path: Path, n: int, m: int,
                edges: List[Tuple[int, int]], layers: List[List[int]]) -> None:
    """按照输入相同的文本格式写出图。"""
    with file_path.open("w", encoding="utf-8") as f:
        f.write(f"{n} {m}\n")
        for u, v in edges:
            f.write(f"{u} {v}\n")
        f.write(f"{len(layers)}\n")
        for layer in layers:
            if layer:
                f.write(" ".join(map(str, layer)) + "\n")
            else:
                f.write("\n")


# ----------------------------------------------------------------------
# Ⅱ  基本工具
# ----------------------------------------------------------------------
def build_node_to_layer(layers: List[List[int]]) -> Dict[int, int]:
    """node → 所在层的映射（层号从 0 起）。"""
    mapping = {}
    for idx, layer in enumerate(layers):
        for node in layer:
            mapping[node] = idx
    return mapping


def crossing_count(edges: List[Tuple[int, int]],
                  node_to_layer: Dict[int, int],
                  layers: List[List[int]]) -> int:
    """
    统计当前层次下的边交叉数（仅考虑“同层‑同层”两端的直线）。
    采用最直接的 O(|E|²) 双层逆序计数，足以处理几千条边的实例。
    """
    # 记录每层内部的水平位置（从左到右的索引）
    pos_in_layer = {}
    for lid, layer in enumerate(layers):
        for pos, node in enumerate(layer):
            pos_in_layer[node] = pos

    cnt = 0
    for i in range(len(edges)):
        u1, v1 = edges[i]
        lu1, lv1 = node_to_layer[u1], node_to_layer[v1]
        for j in range(i + 1, len(edges)):
            u2, v2 = edges[j]
            lu2, lv2 = node_to_layer[u2], node_to_layer[v2]

            # 只统计起点层相同且终点层相同的边对
            if lu1 == lu2 and lv1 == lv2:
                # 两条边水平顺序相反即交叉
                if (pos_in_layer[u1] - pos_in_layer[u2]) * (pos_in_layer[v1] - pos_in_layer[v2]) < 0:
                    cnt += 1
    return cnt


def feasible_layers(node: int,
                    node_to_layer: Dict[int, int],
                    edges: List[Tuple[int, int]],
                    max_layer: int) -> Set[int]:
    """
    返回节点在保持 DAG 层次约束下可以放置的层集合。
    约束来源于所有前驱（must be above）和后继（must be below）。
    """
    lower = 0
    upper = max_layer

    # 前驱：所有 (p → node)
    preds = [node_to_layer[p] for p, v in edges if v == node]
    if preds:
        lower = max(lower, max(preds) + 1)

    # 后继：所有 (node → s)
    succs = [node_to_layer[s] for u, s in edges if u == node]
    if succs:
        upper = min(upper, min(succs) - 1)

    # 合法层号必须在 [lower, upper] 之间（闭区间）
    return set(range(lower, upper + 1))


def barycenter_reorder(layers: List[List[int]], edges: List[Tuple[int, int]]) -> List[List[int]]:
    """
    对每一层（除最上层）执行一次 barycenter（重心）排序，
    这是一种在 Sugiyama 流程中常用的交叉降低启发式，
    参考 Wikipedia “Layered graph drawing”【10†L52-L59】。
    """
    # 先建立 node → 层映射（在本函数内部不改变 layers 的顺序）
    node_to_layer = build_node_to_layer(layers)

    # 前向扫过层次；只考虑相邻层之间的前驱关系
    for i in range(1, len(layers)):
        # 前一层节点的水平位置（索引）
        pos_prev = {node: idx for idx, node in enumerate(layers[i - 1])}

        # 计算每个节点的 barycenter（所有前驱在上一层的平均位置）
        bary = {}
        for node in layers[i]:
            # 只取直接前驱且位于上一层的节点
            preds = [p for p, v in edges if v == node and node_to_layer[p] == i - 1]
            if preds:
                bary[node] = sum(pos_prev[p] for p in preds) / len(preds)
            else:
                bary[node] = float('inf')          # 没有前驱的保持原顺序

        # 按 barycenter 升序排列；若相同则按 id 稳定
        layers[i].sort(key=lambda n: (bary[n], n))
    return layers


# ----------------------------------------------------------------------
# Ⅲ  局部搜索 + 重排序
# ----------------------------------------------------------------------
def greedy_layer_adjustment(n: int,
                           edges: List[Tuple[int, int]],
                           layers: List[List[int]],
                           max_iter: int = 10) -> List[List[int]]:
    """
    贪心局部搜索：尝试把每个节点移动到所有合法层，
    只接受能 **严格** 降低交叉数的移动。
    搜索结束后执行一次 barycenter 重排序，以进一步降低交叉。

    参数
    ----
    n        : 顶点数（0 … n‑1）
    edges    : 边列表 [(u, v), …]（有向）
    layers   : 初始层次（每层内部保持输入顺序）
    max_iter : 最大遍历次数（防止极端情况的无限循环）

    返回
    ----
    优化后的层次列表（层内部已按 barycenter 排序）。
    """
    # 保证层内部顺序可重复（按节点 id 排序）——有助于调试和结果可复现
    layers = [sorted(l) for l in layers]

    node_to_layer = build_node_to_layer(layers)
    max_layer = len(layers) - 1
    cur_cross = crossing_count(edges, node_to_layer, layers)

    for it in range(max_iter):
        improved = False
        # 逐节点尝试移动（顺序固定为节点编号，任何顺序均可）
        for v in range(n):
            cur_l = node_to_layer[v]
            cand_layers = feasible_layers(v, node_to_layer, edges, max_layer)
            cand_layers.discard(cur_l)          # 必须真的“移动”

            if not cand_layers:
                continue

            best_l = cur_l
            best_cross = cur_cross
            best_layers_snapshot = None
            best_map_snapshot = None

            for t in cand_layers:
                # 在复制的层次结构中把 v 从 cur_l 移到 t
                new_layers = [list(l) for l in layers]
                new_layers[cur_l].remove(v)

                # 插入时保持层内部的有序（这里仍按 id 排序）
                insert_pos = 0
                while insert_pos < len(new_layers[t]) and new_layers[t][insert_pos] < v:
                    insert_pos += 1
                new_layers[t].insert(insert_pos, v)

                # 更新映射
                new_map = dict(node_to_layer)
                new_map[v] = t

                new_cross = crossing_count(edges, new_map, new_layers)

                if new_cross < best_cross:
                    best_cross = new_cross
                    best_l = t
                    best_layers_snapshot = new_layers
                    best_map_snapshot = new_map

            # 若找到更好的层则接受该移动
            if best_l != cur_l:
                layers = best_layers_snapshot
                node_to_layer = best_map_snapshot
                cur_cross = best_cross
                improved = True
                # 为了让后面的节点感受到最新的层次，直接继续遍历
        if not improved:
            break

    # ------------------------------------------------------------------
    # 最后一次 barycenter 排序（仅在层次不改变的情况下仍可降低交叉）
    # ------------------------------------------------------------------
    layers = barycenter_reorder(layers, edges)

    # 删除空层并重新编号
    compact = [sorted(l) for l in layers if l]   # 重新排序保证可复现
    return compact


# ----------------------------------------------------------------------
# Ⅳ  主入口
# ----------------------------------------------------------------------
def process_file(in_path: Path, out_path: Path, max_iter: int) -> None:
    n, m, edges, layers = read_graph(in_path)
    new_layers = greedy_layer_adjustment(n, edges, layers, max_iter=max_iter)
    write_graph(out_path, n, m, edges, new_layers)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Reduce edge crossings by moving vertices between layers "
                    "in directed layered graphs."
    )
    parser.add_argument("-i", "--input", required=True,
                        help="Folder that contains the source *.txt files.")
    parser.add_argument("-o", "--output", required=True,
                        help="Folder where the optimized *.txt files will be written.")
    parser.add_argument("-it", "--iterations", type=int, default=10,
                        help="Maximum number of full sweeps over all vertices "
                             "(default: 10).")
    args = parser.parse_args()

    in_dir = Path(args.input)
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    txt_files = list(in_dir.glob("*.txt"))
    if not txt_files:
        print(f"[!] No .txt files found in {in_dir}")
        return

    for src in txt_files:
        dst = out_dir / src.name
        print(f"Optimising {src.name} → {dst.name} ...")
        process_file(src, dst, max_iter=args.iterations)

    print("All files processed.")


if __name__ == "__main__":
    main()
